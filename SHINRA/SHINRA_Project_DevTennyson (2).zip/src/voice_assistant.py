import speech_recognition as sr
import pyttsx3

engine = pyttsx3.init()
recognizer = sr.Recognizer()

def speak(text):
    engine.say(text)
    engine.runAndWait()

def listen():
    with sr.Microphone() as source:
        print("Listening...")
        audio = recognizer.listen(source)
        try:
            return recognizer.recognize_google(audio)
        except sr.UnknownValueError:
            return "Sorry, I didn't catch that."

if __name__ == "__main__":
    speak("Hello, I am SHINRA. How can I help you today?")
    while True:
        command = listen().lower()
        if "exit" in command:
            speak("Goodbye!")
            break
        elif "your name" in command:
            speak("My name is SHINRA, your AI assistant.")
        else:
            speak("I am still learning. Please try another command.")
